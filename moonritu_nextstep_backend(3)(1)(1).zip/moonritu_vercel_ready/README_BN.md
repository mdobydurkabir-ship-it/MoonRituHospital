# Moonritu Medical & Dental Center — Vercel + Supabase booking-ready package

## এই সংস্করণে নতুন
- Appointment form `/api/appointment` server endpoint-এ request জমা দেওয়ার চেষ্টা করে।
- Supabase database schema এবং secure server-side insert প্রস্তুত করা হয়েছে।
- Server/database configuration না থাকলে WhatsApp fallback চালু হয়।
- API input validation (নাম, বাংলাদেশি মোবাইল, date, department) যোগ করা হয়েছে।
- Request save হলেও appointment **pending**; center confirm না করা পর্যন্ত নিশ্চিত বুকিং নয়।

## Backend চালু করার ধাপ
1. Supabase-এ project তৈরি করে SQL Editor-এ `supabase/schema.sql` চালান।
2. Vercel-এ এই project deploy করুন (Git repository import সবচেয়ে সুবিধাজনক)।
3. Vercel Project → Settings → Environment Variables-এ `SUPABASE_URL` এবং `SUPABASE_SERVICE_ROLE_KEY` দিন। Service role key গোপন রাখুন, frontend-এ দেবেন না।
4. Vercel redeploy করুন। `/api/appointment` POST route-টি তখন database-এ request save করবে।
5. Live deployment-এর পরে valid test request দিয়ে API, DB row, fallback behavior যাচাই করুন।

## এখনো production-এর জন্য বাকি
- Supabase/Vercel account ও credentials owner-এর মাধ্যমে configure করা হয়নি।
- Admin authentication/dashboard, appointment confirmation workflow, rate-limit/anti-spam, retention policy, HTTPS/domain setup ও privacy review এখনো দরকার।
- Doctor list/test catalog এখনও prototype/placeholder; center কর্তৃপক্ষের যাচাই প্রয়োজন।
- WhatsApp fallback destination is currently configured in frontend; verify center's WhatsApp number before launch.
