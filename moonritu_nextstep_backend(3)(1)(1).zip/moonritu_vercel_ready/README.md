# Moonritu Medical & Dental Center — Vercel + Supabase deployment package

Responsive static website/PWA with appointment API scaffold. The API endpoint writes appointment requests to Supabase using a private service-role key. Public clients have no direct table access because RLS is enabled with no public policies.

See README_BN.md for deployment steps. Requires `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` in Vercel environment variables and the `supabase/schema.sql` migration applied. Requests are pending until center staff confirm.

Demo doctor schedules, browser-local doctor admin tools, and test catalog are still prototype content. Review before launch. Additional security measures (rate limiting, anti-spam, privacy/retention policy, staff authentication/admin UI) are required before production use.
