-- Apply in Supabase SQL Editor before enabling the appointment endpoint.
create table if not exists public.appointment_requests (
  id bigint generated always as identity primary key,
  reference text not null unique,
  patient_name text not null,
  phone text not null,
  requested_date date not null,
  department text not null,
  doctor_preference text,
  message text,
  status text not null default 'pending' check (status in ('pending','confirmed','cancelled','completed')),
  created_at timestamptz not null default now()
);
create index if not exists appointment_requests_date_idx on public.appointment_requests (requested_date);
create index if not exists appointment_requests_status_idx on public.appointment_requests (status);
alter table public.appointment_requests enable row level security;
-- No public policies: anon/authenticated clients cannot read or write. The server endpoint uses
-- the service-role key privately (never expose it in frontend code or git).
