// Vercel serverless endpoint. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in project environment.
const { createClient } = require('@supabase/supabase-js');
const phonePattern = /^(?:\+?88)?01[3-9]\d{8}$/;
function clean(value, max) { return typeof value === 'string' ? value.trim().slice(0, max) : ''; }
module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return res.status(405).json({ error: 'Method not allowed' }); }
  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) return res.status(503).json({ error: 'Booking server is not configured' });
  const body = req.body || {};
  const name = clean(body.name, 100), phone = clean(body.phone, 20), date = clean(body.date, 10);
  const department = clean(body.department, 100), doctor = clean(body.doctor, 100), message = clean(body.message, 500);
  if (name.length < 2 || !phonePattern.test(phone) || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !department) return res.status(400).json({ error: 'Please provide valid name, Bangladesh mobile number, date, and department.' });
  if (date < new Date().toISOString().slice(0, 10)) return res.status(400).json({ error: 'Appointment date must be today or later.' });
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
  const reference = 'MR-' + Date.now().toString(36).toUpperCase();
  const { error } = await supabase.from('appointment_requests').insert({ reference, patient_name: name, phone, requested_date: date, department, doctor_preference: doctor || null, message: message || null, status: 'pending' });
  if (error) { console.error('appointment insert failed:', error.code); return res.status(500).json({ error: 'Could not save booking request. Please try WhatsApp.' }); }
  return res.status(201).json({ ok: true, reference, status: 'pending' });
};
